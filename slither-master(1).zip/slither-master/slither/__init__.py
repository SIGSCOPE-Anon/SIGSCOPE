"""
.. include:: ../README.md
"""
from .slither import Slither
