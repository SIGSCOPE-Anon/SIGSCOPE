# Slither doctor

Slither doctor is a tool designed to troubleshoot running Slither on a project.