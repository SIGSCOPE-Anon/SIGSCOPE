from slither.exceptions import SlitherException


class SlitherCoreError(SlitherException):
    pass
