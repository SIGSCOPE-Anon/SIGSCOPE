"""
    Modifier module
"""
from .function_contract import FunctionContract


class Modifier(FunctionContract):
    pass
